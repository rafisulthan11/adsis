<?php defined('BLUDIT') or die('Bludit CMS.');

if ($themePlugin == false) {
  exit("To ensure proper functionality, the theme requires the Popeye plugin. Activate the plugin through the admin panel.");
}
